import UIKit


/*
 13.구조체 (Struct )
 - Call by value
 - Big CamelCace
 
 - 선언부 Definition
  struct 이름 {
 }
 */

struct Sample {
    //가변 프로퍼티 : 값 변경 가능
    var mutableProperty :Int = 100
    
    //불변 프로퍼티 : 값이 변경불가능
    let immutableProperty :Int = 100
    
    //타입 프로퍼티
    static var typeProperty : Int = 100
    
    //인스턴스 함수 (인스턴스가 사용하는 메서드)
    func istanceMethod(){
        print("instancde method")
    }
    
    //타입 메서드 ( static 키워드 사용 : 타입자체가 사용하는 메서드)
    static func typeMethod(){
        print("type method")
    }
}

//가변 인스턴스 생성
var mutable:Sample = Sample()
mutable.mutableProperty = 200

//컴파일 오류발생
//불변 프로퍼티는 인스턴스가 생성 된 이후에 수정 불가능하다
//mutable.immutableProperty = 200

//불변 인스턴스 생성
let immutable:Sample = Sample()

//컴파일 오류 발생
//불변 인스턴의 경우, 프로퍼티가 가변이어도 인스턴스가 생성이 된 후에 수정할 수 없다.
//immutable.mutableProperty = 10
//immutable.immutableProperty = 20

//타입 프로퍼티 및 메소드
Sample.typeProperty = 200
Sample.typeMethod()

//컴파일오류 발생
//인스턴스에서는 타입 메소드나 프로퍼티를 사용할 수 없다.
//mutable.typeProperty = 300
//mutable.typeMethod()
